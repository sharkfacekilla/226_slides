from Game import Game


g = Game()
g.start()
