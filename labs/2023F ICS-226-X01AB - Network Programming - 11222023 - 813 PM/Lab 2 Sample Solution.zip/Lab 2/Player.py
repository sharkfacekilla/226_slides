class Player:
    def __init__(self, name: str):
        """
        Creates a new Player with the given name.

        :param name: The name of the Player
        """
        self.name = name
        self.score = 0

    def __str__(self):
        return self.name
