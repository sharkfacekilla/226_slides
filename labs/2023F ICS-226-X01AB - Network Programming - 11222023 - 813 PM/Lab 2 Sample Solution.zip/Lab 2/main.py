from random import randrange
from Board import Board, Direction
from View import display, display_scores


def place_player(board: Board, name: str) -> None:
    """
    Place a player with the given name on the given board at a free location.

    :param board: The board to use
    :param name: The name of the player that should be created
    """
    n = len(board.board)
    while True:
        try:
            board.add_player(name, randrange(n), randrange(n))
            return
        except ValueError:
            continue


board_size = 10
b = Board(board_size, 5, 5, 10, 2)
place_player(b, '1')
place_player(b, '2')

cmd = None
direction = None
while b.num_treasures > 0:
    display(b)
    cmd = input('(U)p (L)eft (R)ight (D)own (Q)uit? ').upper()
    match cmd:

        case 'U':
            direction = Direction('UP')
        case 'L':
            direction = Direction('LEFT')
        case 'R':
            direction = Direction('RIGHT')
        case 'D':
            direction = Direction('DOWN')
        case 'Q':
            break
        case _:
            print('Unknown command')
            continue

    player = input('1 or 2? ')
    match player:
        case '1' | '2':
            try:
                val = b.move_player(player, direction)
            except ValueError as details:
                print(details)
                continue
            else:
                if val != 0:
                    print(f'+{val}')

        case _:
            print('Unknown player')
            continue

display_scores(b)
