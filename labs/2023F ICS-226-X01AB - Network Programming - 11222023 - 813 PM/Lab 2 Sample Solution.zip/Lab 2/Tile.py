from Treasure import Treasure
from Player import Player


class Tile:
    def __init__(self, treasure: Treasure = None, description: str = '.'):
        """
        Initializes a Tile.

        :param treasure: A Treasure associated with the current Tile, if any
        :param description: A description of the Tile
        """
        self.treasure = treasure
        self.description = description
        self.player = None

    def __str__(self):
        player_str = ' ' if self.player is None else str(self.player)
        treasure_str = ' ' if self.treasure is None else str(self.treasure)
        return f' {treasure_str}{self.description}{player_str} '

    def add_player(self, player: Player) -> None:
        """
        Adds a Player to the Tile.

        :param player: The Player to be added; will remove any existing Player at this Tile
        """
        self.player = player
