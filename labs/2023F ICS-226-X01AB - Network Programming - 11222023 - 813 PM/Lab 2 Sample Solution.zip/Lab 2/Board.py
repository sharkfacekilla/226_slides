from random import randrange
from Tile import Tile
from Treasure import Treasure
from Player import Player
from enum import Enum


#
# Hint: This is a first attempt; there is a _better_ way that avoids accessing other object's
# instance variables
#


class Direction(Enum):
    UP = 'UP'
    LEFT = 'LEFT'
    RIGHT = 'RIGHT'
    DOWN = 'DOWN'


class Board:
    def __init__(self, n: int, t: int, min_val: int, max_val: int, max_players: int):
        """
        Initializes a Board.

        Treasures are given random values and are randomly placed on this Board.
        :param n: The dimension of the 2D Board; raises a ValueError if n < 2
        :param t: The number of treasures in the Board; raises a ValueError if n < t
        :param min_val: The minimum value of a Treasure; raises a ValueError if min_val < 1
        :param max_val: The maximum value of a Treasure; raises a ValueError if max_val < min_val
        :param max_players: The maximum number of Players; raises a ValueError if max_players < 0 or n < max_players
        """
        if n < 2:
            raise ValueError("n must not be less than 2")

        if n < t:
            raise ValueError("n must not be less than t")

        if min_val < 1:
            raise ValueError("min_val must not be less than 1")

        if max_val < min_val:
            raise ValueError("max_val must not be less than min_val")

        if max_players < 0 or n < max_players:
            raise ValueError("max_players must be in range 0 <= max_players <= n")

        self.board = [[Tile() for _ in range(n)] for _ in range(n)]

        self.num_treasures = t
        for _ in range(t):
            while True:
                x = randrange(n)
                y = randrange(n)
                if self.board[x][y].treasure is None:
                    self.board[x][y].treasure = Treasure(randrange(min_val, max_val + 1))
                    break

        self.max_players = max_players
        self.players = {}

    def add_player(self, name: str, x: int, y: int) -> None:
        """
        Add a Player with the given name to the Tile at the given Board position.

        :param name: The name of the Player to be added; raises a ValueError if the name already exists or there are too
         many Players
        :param x: The x position of the Player; raises a ValueError if x is not in range 0 <= x < n or a Player already
         is at that location, n being the row size
        :param y: The y position of the Player; raises a ValueError if y is not in range 0 <= y < n or a Player already
         is at that location, n being the column size
        """
        n = len(self.board)
        if not (0 <= x < n):
            raise ValueError("x is not in range 0 <= x < n")

        if not (0 <= y < n):
            raise ValueError("y is not in range 0 <= y < n")

        if not(self.board[x][y].player is None):
            raise ValueError("position not empty")

        if name in self.players:
            raise ValueError("name already exists")

        if len(self.players) == self.max_players:
            raise ValueError("cannot add any more players")

        p = Player(name)
        self.players[name] = (p, (x, y))
        self.board[x][y].player = p

    def move_player(self, name: str, direction: Direction) -> int:
        """
        Move the Player with the given name in the given Direction.

        Any Treasure at the new location is picked up by the Player, and the score is updated accordingly.
        :param name: The name of the Player to be moved.  Raises a ValueError if the Player does not exist
        :param direction: The Direction in which the Player should move.  Raises a ValueError if that is not possible.
        :return: The value of the picked-up Treasure, or 0
        """
        if not (name in self.players):
            raise ValueError("no such player exists")

        (p, (x, y)) = self.players[name]
        new_x = x
        new_y = y
        match direction:
            case Direction.UP:
                if x == 0:
                    raise ValueError("already at the top")
                new_x = x - 1
            case Direction.LEFT:
                if y == 0:
                    raise ValueError("already at the left edge")
                new_y = y - 1
            case Direction.RIGHT:
                if y == len(self.board) - 1:
                    raise ValueError("already at the right edge")
                new_y = y + 1
            case Direction.DOWN:
                if x == len(self.board) - 1:
                    raise ValueError("already at the bottom")
                new_x = x + 1
            case _:
                raise ValueError("unexpected direction")

        if not (self.board[new_x][new_y].player is None):
            raise ValueError("already occupied")

        self.players[name] = (p, (new_x, new_y))
        self.board[x][y].player = None
        self.board[new_x][new_y].player = p
        if not (self.board[new_x][new_y].treasure is None):
            t = self.board[new_x][new_y].treasure
            p.score += t.value
            self.board[new_x][new_y].treasure = None
            self.num_treasures -= 1
            return t.value

        return 0
