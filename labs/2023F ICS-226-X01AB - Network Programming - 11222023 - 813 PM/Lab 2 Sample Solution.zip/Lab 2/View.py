from Board import Board

#
# Hint: This is a first attempt; there is a _better_ way that avoids accessing other object's
# instance variables
#

def display(board: Board) -> None:
    """
    Prints out a Board to stdout.

    :param board: The Board to be displayed on stdout
    """
    for row in board.board:
        for cell in row:
            print(cell, end='')
        print()


def display_scores(board: Board) -> None:
    """
    Prints out the scores of all Players.

    :param board: The Board containing the Players
    """
    for (p, (x, y)) in board.players.values():
        print(f'{p.name}: {p.score}')
